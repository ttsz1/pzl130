import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../android/old/auth_screen.dart';
import 'screens/set_new_password_screen.dart';

class StartupRouter extends StatefulWidget {
  const StartupRouter({super.key});

  @override
  State<StartupRouter> createState() => _StartupRouterState();
}

class _StartupRouterState extends State<StartupRouter> {
  bool _exchanging = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final params = Uri.base.queryParameters;
    final code = params['code'];

    if (code != null) {
      setState(() {
        _exchanging = true;
      });
      Supabase.instance.client.auth.exchangeCodeForSession(code).then((response) {
        if (response.session != null) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const SetNewPasswordScreen(),
            ),
          );
        } else {
          setState(() {
            _error = "Nie udało się wymienić kodu na sesję (brak session).";
            _exchanging = false;
          });
        }
      }).catchError((e) {
        setState(() {
          _error = "Błąd: $e";
          _exchanging = false;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_exchanging) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return Scaffold(
        body: Center(child: Text(_error!, style: TextStyle(color: Colors.red))),
      );
    }
    return const AuthScreen();
  }
}