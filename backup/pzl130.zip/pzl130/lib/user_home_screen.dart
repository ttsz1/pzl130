import 'package:flutter/material.dart';

class UserHomeScreen extends StatelessWidget {
  final String firstName;
  final String lastName;
  final String title;
  final bool isAdmin;

  const UserHomeScreen({
    super.key,
    required this.firstName,
    required this.lastName,
    required this.title,
    required this.isAdmin,
  });

  void _goTo(BuildContext context, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<_MenuItem> menuItems = [
      _MenuItem(
        label: 'Tryb nauki',
        icon: Icons.school,
        gradient: const LinearGradient(colors: [Colors.blue, Colors.lightBlueAccent]),
        onTap: () => _goTo(context, const PlaceholderScreen(title: "Tryb nauki")),
      ),
      _MenuItem(
        label: 'Tryb quizu',
        icon: Icons.quiz,
        gradient: const LinearGradient(colors: [Colors.purple, Colors.deepPurpleAccent]),
        onTap: () => _goTo(context, const PlaceholderScreen(title: "Tryb quizu")),
      ),
      _MenuItem(
        label: 'Tryb testu',
        icon: Icons.fact_check,
        gradient: const LinearGradient(colors: [Colors.green, Colors.lightGreenAccent]),
        onTap: () => _goTo(context, const PlaceholderScreen(title: "Tryb testu")),
      ),
      _MenuItem(
        label: 'Moje wyniki',
        icon: Icons.leaderboard,
        gradient: const LinearGradient(colors: [Colors.orange, Colors.deepOrangeAccent]),
        onTap: () => _goTo(context, const PlaceholderScreen(title: "Moje wyniki")),
      ),
    ];

    if (isAdmin) {
      menuItems.add(
        _MenuItem(
          label: 'Tryb admin',
          icon: Icons.admin_panel_settings,
          gradient: const LinearGradient(colors: [Colors.red, Colors.redAccent]),
          onTap: () => _goTo(context, const PlaceholderScreen(title: "Tryb admin")),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Panel użytkownika'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: Center(
              child: Text(
                "Witaj, $title $firstName $lastName",
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
      body: Center(
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
          itemCount: menuItems.length,
          separatorBuilder: (_, __) => const SizedBox(height: 18),
          itemBuilder: (context, index) {
            final item = menuItems[index];
            return _FancyMenuCard(item: item);
          },
        ),
      ),
    );
  }
}

class _MenuItem {
  final String label;
  final IconData icon;
  final LinearGradient gradient;
  final VoidCallback onTap;

  _MenuItem({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.onTap,
  });
}

class _FancyMenuCard extends StatelessWidget {
  final _MenuItem item;

  const _FancyMenuCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: item.onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: item.gradient,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: item.gradient.colors.last.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(4, 8),
            ),
          ],
        ),
        height: 75,
        child: Row(
          children: [
            const SizedBox(width: 20),
            CircleAvatar(
              radius: 25,
              backgroundColor: Colors.white.withOpacity(0.85),
              child: Icon(item.icon, color: item.gradient.colors[0], size: 32),
            ),
            const SizedBox(width: 26),
            Expanded(
              child: Text(
                item.label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  shadows: [
                    Shadow(
                      blurRadius: 5,
                      color: Colors.black26,
                      offset: Offset(1, 2),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 18),
            const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 28),
            const SizedBox(width: 16),
          ],
        ),
      ),
    );
  }
}

// Tymczasowy placeholder dla nowych ekranów:
class PlaceholderScreen extends StatelessWidget {
  final String title;
  const PlaceholderScreen({required this.title});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(child: Text('Tutaj będzie: $title', style: const TextStyle(fontSize: 24))),
    );
  }
}