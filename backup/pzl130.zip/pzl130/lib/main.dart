import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'user_home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PZL-130 Orlik TC-II',
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF4a5d23), // militarna zieleń
        scaffoldBackgroundColor: const Color(0xFF232d28), // ciemne tło
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: const Color(0xFFb22222), // szachownica/czerwony
        ),
        textTheme: GoogleFonts.oswaldTextTheme(
          Theme.of(context).textTheme,
        ).apply(
          bodyColor: Colors.white,
          displayColor: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF232d28),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4a5d23),
            foregroundColor: Colors.white,
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            elevation: 5,
            shadowColor: Colors.black87,
          ),
        ),
      ),
      home: const UserHomeScreen(
        firstName: 'Hubert',
        lastName: 'Hendel',
        title: 'kpt.',
        isAdmin: true,
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}